﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MainPage : System.Web.UI.Page
{

    enum Days { Sun, Mon, tue, Wed, thu, Fri, Sat };
    enum Season { spring, summer, fall, winter};
    public int CalculateSeason(string month)
    {
        int seasonNum = 0;
        switch (month)
        {
            case "01":
            case "02":
            case "03":
                seasonNum = (int)Season.spring+1;  
            break; /* optional */
            case "04":
            case "05":
            case "06":
            seasonNum = (int)Season.summer + 1;
            break;
            case "07":
            case "08":
            case "09":
            seasonNum = (int)Season.fall + 1;
            break;
            case "10":
            case "11":
            case "12":
            seasonNum = (int)Season.winter + 1;
            break;

        }
        return seasonNum;
    }
    public int CalculateWeatherDesc(string desc)
    {
        int weatherDesc = 1;
        switch (desc)
        {
            case "Clear":
            case "Few Clouds":
            case "Partly Cloudy":
                weatherDesc = 1;
                break; /* optional */
            case "Mist":
            case "Mist + Cloudy":
            case "Mist + Broken clouds":
            case "Mist + Few clouds":
                weatherDesc = 2;
                break;
            case "Light Snow":
            case "Light Rain + Thunderstorm + Scattered clouds":
            case "Light Rain + Scattered clouds ":
                weatherDesc = 3;
                break;
            case "Heavy Rain + Ice Pallets + Thunderstorm + Mist":
            case "Snow + Fog ":
                weatherDesc = 4;
                break;

        }
        return weatherDesc;
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_Submit_Click(object sender, EventArgs e)
    {
         WebInput webdataInput = new WebInput();
         webdataInput.date = Request.Form["datetxt"];
         webdataInput.time = Request.Form["timetxt"];
         string monthStr = (webdataInput.date.Substring(5, 2));
         webdataInput.datetime = webdataInput.date + " " + webdataInput.time;
         webdataInput.season = CalculateSeason(monthStr);
         webdataInput.holiday =int.Parse(Request.Form["holidayradio"].ToString());
         int dow = int.Parse(Request.Form["dayofweek"]);
         webdataInput.workingDay = int.Parse("1");
         if ((webdataInput.holiday != 1) && (dow==5 || dow==6)){webdataInput.workingDay = int.Parse("0");}
         webdataInput.weatherDesc = CalculateWeatherDesc(Request.Form["desctxt"]);
         webdataInput.temperature = double.Parse(Request.Form["temptxt"]);
         webdataInput.temperatureLike = double.Parse(Request.Form["feelsLiketxt"]);
         webdataInput.humidity = double.Parse(Request.Form["humiditytxt"]);
         webdataInput.windspeed = double.Parse(Request.Form["windspeedtxt"]);
        
         string predictCasualRiders = SmartBikeAnalysis.PredictCasualRiders(webdataInput);
         string predictRegisteredRiders = SmartBikeAnalysis.PredictRegisteredRiders(webdataInput);

         if (predictCasualRiders != "Error")
         {
             Request.Form["casriders"] = predictCasualRiders;
             //predictedLabel.Visible = true;
             
         }

         if (predictRegisteredRiders != "Error")
         {
             Request.Form["regriders"] = predictRegisteredRiders;
             
         }
     }
    
}