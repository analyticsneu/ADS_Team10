﻿// This code requires the Nuget package Microsoft.AspNet.WebApi.Client to be installed.
// Instructions for doing this in Visual Studio:
// Tools -> Nuget Package Manager -> Package Manager Console
// Install-Package Microsoft.AspNet.WebApi.Client

using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

public class StringTable
{
    public string[] ColumnNames { get; set; }
    public string[,] Values { get; set; }
}

public class SmartBikeAnalysis
{

    public static string PredictCasualRiders(WebInput dataset)
    {
        using (var client = new HttpClient())
        {
            var scoreRequest = new
            {

                Inputs = new Dictionary<string, StringTable>() { 
                        { 
                            "input1", 
                            new StringTable() 
                            {
                                ColumnNames = new string[] {"datetime", "season", "holiday", "workingday", "weather", "temp", "atemp", "humidity", "windspeed"},
                                Values = new string[,] {  { dataset.datetime, Convert.ToString(dataset.season), Convert.ToString(dataset.holiday), Convert.ToString(dataset.workingDay), Convert.ToString(dataset.weatherDesc), Convert.ToString(dataset.temperature), Convert.ToString(dataset.temperatureLike), Convert.ToString(dataset.humidity), Convert.ToString(dataset.windspeed) },  { dataset.datetime, Convert.ToString(dataset.season), Convert.ToString(dataset.holiday), Convert.ToString(dataset.workingDay), Convert.ToString(dataset.weatherDesc), Convert.ToString(dataset.temperature), Convert.ToString(dataset.temperatureLike), Convert.ToString(dataset.humidity), Convert.ToString(dataset.windspeed) },  }
                            }
                        },
                    },
                GlobalParameters = new Dictionary<string, string>()
                {
                }
            };
            const string apiKey = "Pj7dFOru9gz1CZ7rblVQ4QDlB1qLBb8uwn8kEdRzIWzGsa/rMDo1ky0TMjxPv9R8YKUh9VRW5vgVxPpjPEF9/w==";
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

            client.BaseAddress = new Uri("https://ussouthcentral.services.azureml.net/workspaces/65817a10f4a4452db8059313c8182a68/services/754dfeaaacdd4dfe80519f7719d1bcca/execute?api-version=2.0&details=true");


            //CALL WEB SERVICE
            HttpResponseMessage response = client.PostAsJsonAsync("", scoreRequest).Result;

            //Work with response
            if (response.IsSuccessStatusCode)
            {
                string jsondocument = response.Content.ReadAsStringAsync().Result;


                var responseBody = JsonConvert.DeserializeObject<RRSResponseObject>(jsondocument);
                return responseBody.Results.output1.value.Values[0][0];

            }
            else
            {
                return "Error";
            }
        }
    }

    public static string PredictRegisteredRiders(WebInput dataset1)
    {
        using (var client1 = new HttpClient())
        {
            var scoreRequest1 = new
            {

                Inputs = new Dictionary<string, StringTable>() { 
                        { 
                            "input1", 
                            new StringTable() 
                            {
                                ColumnNames = new string[] {"datetime", "season", "holiday", "workingday", "weather", "temp", "atemp", "humidity", "windspeed"},
                                Values = new string[,] {  {dataset1.datetime, Convert.ToString(dataset1.season), Convert.ToString(dataset1.holiday), Convert.ToString(dataset1.workingDay), Convert.ToString(dataset1.weatherDesc), Convert.ToString(dataset1.temperature), Convert.ToString(dataset1.temperatureLike), Convert.ToString(dataset1.humidity), Convert.ToString(dataset1.windspeed) },  { dataset1.datetime, Convert.ToString(dataset1.season), Convert.ToString(dataset1.holiday), Convert.ToString(dataset1.workingDay), Convert.ToString(dataset1.weatherDesc), Convert.ToString(dataset1.temperature), Convert.ToString(dataset1.temperatureLike), Convert.ToString(dataset1.humidity), Convert.ToString(dataset1.windspeed)},  }
                            }
                        },
                    },
                GlobalParameters = new Dictionary<string, string>()
                {
                }
            };
            const string apiKey = "PJpX1CputxUHdLMqQJtO+1cdkglVUtBfqm6HirMgyJ+1RAwth+MgbnXZ6itjNU1ukUI3MoFpQ5RQY+Gm7hfqyg==";
            client1.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

            client1.BaseAddress = new Uri("https://ussouthcentral.services.azureml.net/workspaces/65817a10f4a4452db8059313c8182a68/services/478ba1eac0a0419eb3212699f0cd6e33/execute?api-version=2.0&details=true");


            //CALL WEB SERVICE
            HttpResponseMessage response = client1.PostAsJsonAsync("", scoreRequest1).Result;

            //Work with response
            if (response.IsSuccessStatusCode)
            {
                string jsondocument = response.Content.ReadAsStringAsync().Result;


                var responseBody = JsonConvert.DeserializeObject<RRSResponseObject>(jsondocument);
                return responseBody.Results.output1.value.Values[0][0];

            }
            else
            {
                return "Error";
            }
        }
    }
}


#region Helper Classes
public class RRSResponseObject
{
    public Results Results { get; set; }
}

public class Results
{
    public Output1 output1 { get; set; }
}

public class Output1
{
    public string type { get; set; }
    public Value value { get; set; }
}

public class Value
{
    public string[] ColumnNames { get; set; }
    public string[] ColumnTypes { get; set; }
    public string[][] Values { get; set; }
} 
#endregion


