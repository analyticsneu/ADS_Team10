﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for WebInput
/// </summary>
public class WebInput
{
	public WebInput()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public string date { get; set; }
    public string time { get; set; }
    public string datetime { get; set; }
    public int season { get; set; }
    public int holiday { get; set; }
    public int workingDay { get; set; }
    public int weatherDesc { get; set; }
    public double temperature { get; set; }
    public double temperatureLike { get; set; }
    public double humidity { get; set; }
    public double windspeed { get; set; }
    public double casualRiders { get; set; }
    public double registerRiders { get; set; }
    public double totalRiders { get; set; }
}